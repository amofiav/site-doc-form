// 🔍 Populate input, radio, checkbox, and textarea fields from given data object
export function populateFields(containerId, data) {
  const container = document.getElementById(containerId);
  if (!container || !data) {
    console.warn(`⚠️ Missing container "${containerId}" or data is null.`);
    return;
  }

  console.log(`📥 Populating fields in #${containerId}`);
  Object.entries(data).forEach(([key, value]) => {
    const elements = container.querySelectorAll(`[name='${key}']`);

    if (elements.length === 0) {
      console.log(`ℹ️ No elements found for "${key}" in #${containerId} (ok if optional field)`);
      return; // skip missing fields without warning
    }

    elements.forEach(el => {
      if (el.type === "radio") {
        el.checked = (el.value === value);
      } else if (el.type === "checkbox") {
        if (Array.isArray(value)) {
          el.checked = value.includes(el.value);
        } else {
          el.checked = Boolean(value);
        }
      } else if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
        el.value = value;
      }
    });
  });
}

// 📥 Fetch latest site-specific data and prefill fields
export async function prefillSiteData(site) {
  try {
    const res = await fetch("https://oqvwp8amk6.execute-api.us-east-2.amazonaws.com/v1/getSubmissions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });

    const data = await res.json();
    const matches = (data.submissions || []).filter(sub => sub.site === site);
    if (!matches.length) return;

    const latest = matches.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))[0];
    console.log("📤 siteData:", latest.siteData);
    populateFields("siteSpecificFields", latest.siteData);
  } catch (err) {
    console.error("❌ Failed to prefill site data:", err);
  }
}

// 📥 Fetch latest unit-specific data and prefill fields (including notes)
export async function prefillUnitData(site, unit) {
  try {
    const res = await fetch("https://oqvwp8amk6.execute-api.us-east-2.amazonaws.com/v1/getSubmissions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });

    const data = await res.json();
    const matches = (data.submissions || []).filter(sub => sub.site === site && sub.unit === unit);
    if (!matches.length) return;

    const latest = matches.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))[0];
    console.log("📤 unitData:", latest.unitData);
    populateFields("unitSpecificFields", latest.unitData);

    // 📝 Handle "notes" separately because it's outside the main container
    if (latest.unitData?.notes !== undefined) {
      const notesField = document.getElementById("notes");
      if (notesField) {
        console.log("📝 Populating notes field:", latest.unitData.notes);
        notesField.value = latest.unitData.notes;
      }
    }
  } catch (err) {
    console.error("❌ Failed to prefill unit data:", err);
  }
}
