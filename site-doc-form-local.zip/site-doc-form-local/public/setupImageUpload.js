export function setupImageUpload() {
  const addBtn = document.getElementById("addUnitImageButton");
  if (!addBtn) return;

  addBtn.addEventListener("click", () => {
    const container = document.getElementById("unitImageContainer");
    if (!container) return;

    const div = document.createElement("div");
    div.className = "image-entry";

    const file = document.createElement("input");
    file.type = "file";
    file.accept = "image/*";
    file.capture = "environment";

    const desc = document.createElement("input");
    desc.type = "text";
    desc.placeholder = "Enter description";

    div.appendChild(file);
    div.appendChild(desc);
    container.appendChild(div);
  });
}
