import { uploadImagesFrom } from "./imageUpload.js";
import { loadSitesAndUnits } from "./siteDropdownPromise.js";
import { showNewSite, showNewUnit } from "./main.js";

export function setupSubmitButton() {
    const submitBtn = document.getElementById("submitButton");

    submitBtn.addEventListener("click", async (event) => {
        event.preventDefault();

        const siteDropdown = document.getElementById("siteDropdown");
        const siteInput = document.getElementById("siteName"); // New Site input
        const unitDropdown = document.getElementById("unitDropdown");
        const unitInput = document.getElementById("unitName"); // New Unit input

        // 🛠️ Add new Site if typed but not selected
        if (siteDropdown.value === "" && siteInput && siteInput.value.trim() !== "") {
            console.log("⚡ Adding new site to dropdown during submit:", siteInput.value.trim());
            const newOption = document.createElement("option");
            newOption.value = siteInput.value.trim();
            newOption.textContent = siteInput.value.trim();
            siteDropdown.appendChild(newOption);
            siteDropdown.value = siteInput.value.trim();
        }

        // 🛠️ Add new Unit if typed but not selected
        if (unitDropdown.value === "" && unitInput && unitInput.value.trim() !== "") {
            console.log("⚡ Adding new unit to dropdown during submit:", unitInput.value.trim());
            const newOption = document.createElement("option");
            newOption.value = unitInput.value.trim();
            newOption.textContent = unitInput.value.trim();
            unitDropdown.appendChild(newOption);
            unitDropdown.value = unitInput.value.trim();
        }

        const site = siteDropdown.value.trim();
        const unit = unitDropdown.value.trim();
        const notesField = document.getElementById("notes");
        const notes = notesField ? notesField.value.trim() : "";

        // 🛑 Validate before submitting
        if (!site) {
            alert("⚠️ Please select or enter a site before submitting.");
            return;
        }
        if (!unit) {
            alert("⚠️ Please select or enter a unit before submitting.");
            return;
        }

        console.log("🖼️ Uploading images before form submission...");
        const unitImages = await uploadImagesFrom(
            "unitImageContainer",
            "https://oqvwp8amk6.execute-api.us-east-2.amazonaws.com/v1/upload"
        );
        console.log("✅ Uploaded unitImages:", unitImages);

        // 🧠 Collect Site-specific fields dynamically
        const siteSpecificInputs = document.querySelectorAll('#siteSpecificFields input, #siteSpecificFields textarea, #siteSpecificFields select');
        const siteData = {};

        siteSpecificInputs.forEach(input => {
            if (input.type === 'radio') {
                if (input.checked) {
                    siteData[input.name] = input.value;
                }
            } else {
                siteData[input.name] = input.value.trim();
            }
        });

        // 🧠 Collect Unit-specific fields dynamically
        const unitSpecificInputs = document.querySelectorAll('#unitSpecificFields input, #unitSpecificFields textarea, #unitSpecificFields select');
        const unitData = {};

        unitSpecificInputs.forEach(input => {
            if (input.type === 'radio') {
                if (input.checked) {
                    unitData[input.name] = input.value;
                }
            } else {
                unitData[input.name] = input.value.trim();
            }
        });

        // 🧠 Also include the notes separately
        unitData.notes = notes;

        const payload = {
            site,
            unit,
            siteData: siteData,
            unitData: unitData,
            unitImages
        };

        console.log("📦 Submitting payload:", payload);

        const response = await fetch('https://oqvwp8amk6.execute-api.us-east-2.amazonaws.com/v1/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        if (response.ok) {
            const data = await response.json();
            console.log("📨 Server response:", data);

            if (data.message === "Submission stored successfully") {
                alert("✅ Form submitted successfully!");

                // 🔥 Reset the form fields
                siteDropdown.value = "";
                unitDropdown.value = "";
                if (siteInput) siteInput.value = "";
                if (unitInput) unitInput.value = "";
                if (notesField) notesField.value = "";
                document.getElementById("unitImageContainer").innerHTML = "";

                await loadSitesAndUnits(); // Reload dropdowns fresh
            } else {
                alert("❌ Submission error: " + data.message);
            }
        } else {
            alert("❌ Form submission failed. Server returned error.");
        }
    });
}
