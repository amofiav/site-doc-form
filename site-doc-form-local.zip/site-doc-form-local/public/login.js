export function setupLogin() {
  const loginBtn = document.getElementById("loginButton");

  const USERNAME = "admin";
  const PASSWORD = "1234";

  loginBtn.addEventListener("click", () => {
    const username = document.getElementById("loginUsername").value.trim();
    const password = document.getElementById("loginPassword").value.trim();
    const errorMsg = document.getElementById("loginError");

    if (username === USERNAME && password === PASSWORD) {
      // ✅ Login success
      localStorage.setItem("authenticated", "true");
      document.getElementById("loginScreen").style.display = "none";
      document.getElementById("formContainer").style.display = "block";
      errorMsg.style.display = "none";
    } else {
      // ❌ Wrong credentials
      errorMsg.style.display = "block";
    }
  });

  // Auto-login if already authenticated
  if (localStorage.getItem("authenticated") === "true") {
    document.getElementById("loginScreen").style.display = "none";
    document.getElementById("formContainer").style.display = "block";
  }
}
