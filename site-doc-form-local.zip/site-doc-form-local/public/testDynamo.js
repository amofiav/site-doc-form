console.log("🚀 Script started...");

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, GetCommand } from "@aws-sdk/lib-dynamodb";
import assert from 'node:assert';

// 1. Connect to DynamoDB
const client = new DynamoDBClient({ region: "us-east-2" }); // 🔥 Replace with your region if different
const ddbDocClient = DynamoDBDocumentClient.from(client);

// 2. Define your table name and test item
const TABLE_NAME = "SiteSubmissions"; // 🔥 Replace with your actual table name if different
const testSubmission = {
  submissionId: "test123",   // 🔥 Make sure this matches your table's partition key name
  site: "Test Hospital",
  unit: "Test Unit",
  notes: "Testing notes",
};

// 3. Main test function
async function testDynamoDBSave() {
  // Put a test item into DynamoDB
  await ddbDocClient.send(new PutCommand({
    TableName: TABLE_NAME,
    Item: testSubmission,
  }));

  console.log("✅ Item written. Now verifying...");

  // Get the item back from DynamoDB
  const result = await ddbDocClient.send(new GetCommand({
    TableName: TABLE_NAME,
    Key: { submissionId: "test123" },
  }));

  console.log("📦 Fetched item:", result.Item);

  // Verify the item matches
  assert.strictEqual(result.Item?.site, "Test Hospital");
  assert.strictEqual(result.Item?.unit, "Test Unit");

  console.log("✅ DynamoDB test passed!");
}

// 4. Run the test
testDynamoDBSave().catch((err) => {
  console.error("❌ DynamoDB test failed:", err);
  process.exit(1);
});
