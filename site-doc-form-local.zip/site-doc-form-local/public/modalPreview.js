export function setupModalPreview() {
  document.addEventListener('click', function (e) {
    if (e.target.classList.contains('thumb')) {
      const src = e.target.getAttribute('src');
      openModal(src);
    }
  });
}

function openModal(imageSrc) {
  let modal = document.getElementById('imageModal');

  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'imageModal';
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.backgroundColor = 'rgba(0,0,0,0.8)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '9999';
    modal.style.cursor = 'pointer';

    const img = document.createElement('img');
    img.id = 'modalImage';
    img.style.maxWidth = '90%';
    img.style.maxHeight = '90%';
    modal.appendChild(img);

    modal.addEventListener('click', () => {
      modal.remove();
    });

    document.body.appendChild(modal);
  }

  const modalImage = document.getElementById('modalImage');
  modalImage.src = imageSrc;
  modal.style.display = 'flex';
}
