export async function loadSitesAndUnits() {
  const response = await fetch("https://oqvwp8amk6.execute-api.us-east-2.amazonaws.com/v1/getSubmissions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({})
  });

  const data = await response.json();
  const dropdown = document.getElementById("siteDropdown");
  if (!dropdown) {
    console.warn("⚠️ siteDropdown element not found");
    return;
  }

  const siteUnitMap = {};

  (data.submissions || []).forEach(sub => {
    const site = sub.site;
    const unit = sub.unit;

    if (!siteUnitMap[site]) siteUnitMap[site] = new Set();
    if (unit) siteUnitMap[site].add(unit);
  });

  dropdown.innerHTML = `<option value="">-- Choose a Site --</option>`;
  Object.keys(siteUnitMap).sort().forEach(site => {
    const option = document.createElement("option");
    option.value = site;
    option.textContent = site;
    dropdown.appendChild(option);
  });

  window.siteUnitMap = {};
  Object.keys(siteUnitMap).forEach(site => {
    window.siteUnitMap[site] = Array.from(siteUnitMap[site]);
  });
}
