export function setupSurvBlocks() {
  const container = document.getElementById("centralSurvsContainer");
  const addButton = document.getElementById("addSurvButton");
  let survCount = container.children.length;

  addButton.addEventListener("click", () => {
    survCount++;
    const div = document.createElement("div");
    div.className = "form-section image-entry";


    const label = document.createElement("label");
    label.textContent = `Surv ${survCount}:`;

    const input = document.createElement("input");
    input.type = "text";
    input.name = `surv_${survCount}`;
    input.placeholder = "Enter details for this Surv";

    const file = document.createElement("input");
    file.type = "file";
    file.accept = "image/*";
    file.capture = "environment";
    file.name = `survImage_${survCount}`;

    div.appendChild(label);
    div.appendChild(input);
    div.appendChild(file);
    container.appendChild(div);
  });
}

export function renderSurvReviewBlocks(centralSurvs = [], survImages = []) {
  const container = document.getElementById("centralSurvsContainer");
  container.innerHTML = "";

  centralSurvs.forEach((text, index) => {
    const div = document.createElement("div");
    div.className = "form-section";

    const label = document.createElement("label");
    label.textContent = `Surv ${index + 1}:`;

    const input = document.createElement("input");
    input.type = "text";
    input.name = `surv_${index + 1}`;
    input.value = text;

    div.appendChild(label);
    div.appendChild(input);
    container.appendChild(div);
  });

  survImages.forEach((img, index) => {
    const div = container.children[index];
    if (!div) return;

    const imageEntry = document.createElement("div");
    imageEntry.className = "image-entry";

    const thumb = document.createElement("img");
    thumb.src = img.url;
    thumb.alt = img.description || "Surv Image";
    thumb.className = "thumb";
    thumb.onclick = () => {
      const modal = document.getElementById("imageModal");
      const modalImg = document.getElementById("modalImg");
      modalImg.src = img.url;
      modal.style.display = "flex";
    };

    const caption = document.createElement("div");
    caption.textContent = img.description || "";

    imageEntry.appendChild(thumb);
    imageEntry.appendChild(caption);
    div.appendChild(imageEntry);
  });
}
