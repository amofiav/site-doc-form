export async function uploadImagesFrom(containerId, uploadEndpoint) {
  const container = document.getElementById(containerId);
  if (!container) return [];

  const imageEntries = container.querySelectorAll(".image-entry");
  const uploadedImages = [];

  for (const entry of imageEntries) {
    const fileInput = entry.querySelector('input[type="file"]');
    const descInput = entry.querySelector('input[type="text"]');

    if (!fileInput || !fileInput.files.length) continue;

    const file = fileInput.files[0];
    const filename = encodeURIComponent(file.name);
    const description = descInput ? descInput.value : "";

    console.log(`🚀 Uploading with filename and contentType: ${filename} ${file.type}`);

    // 🛠 Correctly wrapped POST body
    const response = await fetch(uploadEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        filename: filename,
        contentType: file.type,
      }),
    });

    const result = await response.json();

    if (!result.uploadUrl) {
      console.error("❌ Missing uploadUrl in Lambda response!", result);
      continue;
    }

    console.log("✅ Got presigned upload URL:", result.uploadUrl);

    const uploadResult = await fetch(result.uploadUrl, {
      method: "PUT",
      headers: {
        "Content-Type": file.type,
      },
      body: file,
    });

    if (!uploadResult.ok) {
      console.error("❌ Failed to upload image to S3", uploadResult);
      continue;
    }

    console.log("✅ Image uploaded successfully!");

    // Remove query string from presigned URL to get the S3 URL
    const uploadedUrl = result.uploadUrl.split("?")[0];

    uploadedImages.push({
      url: uploadedUrl,
      description: description,
    });
  }

  return uploadedImages;
}
