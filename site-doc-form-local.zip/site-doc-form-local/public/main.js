// 🔧 Core data and form setup
import { loadSitesAndUnits } from "./siteDropdownPromise.js";      // ✅ FIXED: Loads site/unit mapping from backend
import { setupSubmitButton } from "./submitButton.js";             // Handles form submission logic
import { setupReviewButton } from "./reviewButton.js";             // Review button logic

// 🧱 Dynamic section builders
import { setupSurvBlocks } from "./survBlocks.js";                 // Adds/removes Surv blocks
import { setupOverviewBlocks } from "./overviewBlocks.js";         // Adds/removes Over View blocks
import { setupImageUpload } from "./setupImageUpload.js";          // 🔥 NEW: Setup UI for image uploads
import { uploadImagesFrom } from "./imageUpload.js";               // 🔥 NEW: Handle uploading images to S3
//import { setupModalPreview } from "./modalPreview.js";             // Enables lightbox modal for image preview

// 🧠 Autofill helpers
import { prefillSiteData, prefillUnitData } from "./prefillFormData.js"; // Prefills form fields based on latest site/unit data


// Static dropdown behavior
export function onHospitalChange() {
  const site = document.getElementById("siteDropdown").value;
  const unitDropdown = document.getElementById("unitDropdown");

  unitDropdown.innerHTML = `<option value="">-- Choose a Unit --</option>`;
  (window.siteUnitMap?.[site] || [])
    .sort((a, b) => a.localeCompare(b)) // Sort units alphabetically
    .forEach(unit => {
      const option = document.createElement("option");
      option.value = unit;
      option.textContent = unit;
      unitDropdown.appendChild(option);
    });

  document.getElementById("newUnitSection").style.display = "none";
  document.getElementById("unitName").value = "";

  // 🔁 Sort the site dropdown alphabetically
  const siteDropdown = document.getElementById("siteDropdown");
  const selectedSite = siteDropdown.value;
  const options = Array.from(siteDropdown.options)
    .filter(opt => opt.value)
    .sort((a, b) => a.textContent.localeCompare(b.textContent));

  siteDropdown.innerHTML = `<option value="">-- Choose a Site --</option>`;
  options.forEach(option => siteDropdown.appendChild(option));
  siteDropdown.value = selectedSite;

  // 🧠 Prefill data
  prefillSiteData(site);
  const unit = unitDropdown.value;
  if (unit) {
    prefillUnitData(site, unit);
  }

  // ✅ Review button now stays visible — no hiding
}

// Trigger new site/unit inputs
export function showNewSite() {
  document.getElementById("siteDropdown").value = "";
  document.getElementById("newSiteSection").style.display = "block";
  
  const newSiteName = document.getElementById("siteName").value;
  if (newSiteName.trim()) {
    const siteDropdown = document.getElementById("siteDropdown");
    const newOption = document.createElement("option");
    newOption.value = newSiteName;
    newOption.textContent = newSiteName;
    siteDropdown.appendChild(newOption);
    siteDropdown.value = newSiteName;
  }
}
window.showNewSite = showNewSite;

export function showNewUnit() {
  document.getElementById("unitDropdown").value = "";
  document.getElementById("newUnitSection").style.display = "block";
}
window.showNewUnit = showNewUnit;

// Toggle collapsible sections
function toggleSections() {
  document.querySelectorAll(".section-header").forEach(header => {
    header.addEventListener("click", () => {
      const content = header.nextElementSibling;
      const isVisible = content.style.display === "block";
      content.style.display = isVisible ? "none" : "block";
      header.classList.toggle("expanded", !isVisible);
    });
  });
}

// Initialize everything on page load
document.addEventListener("DOMContentLoaded", async () => {   // ✅ CHANGED to async
  try {
    await loadSitesAndUnits();           // ✅ await the new function properly
    onHospitalChange();                  // Load and sort dropdowns
    toggleSections();                    // Enable collapsible headers
    setupSurvBlocks();                   // Setup Surv image blocks
    setupOverviewBlocks();               // Setup Over View image blocks
    setupImageUpload();                  // Enable unit image uploads
    setupSubmitButton();                 // Enable form submission
    setupReviewButton();                 // Enable Review button

    document.getElementById("siteDropdown").addEventListener("change", onHospitalChange);
    document.getElementById("unitDropdown").addEventListener("change", () => {
      const site = document.getElementById("siteDropdown").value;
      const unit = document.getElementById("unitDropdown").value;
      if (site && unit) {
        prefillUnitData(site, unit);      // Prefill unit data when unit changes
      }
    });
  } catch (err) {
    console.error("⚠️ Dropdown setup failed:", err);
    alert("Failed to load site/unit data. Please try again later.");
  }
});
