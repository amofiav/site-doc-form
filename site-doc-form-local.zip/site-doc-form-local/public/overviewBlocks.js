export function setupOverviewBlocks() {
  const container = document.getElementById("overviewContainer");
  const addButton = document.getElementById("addOverviewButton");
  let overviewCount = container.children.length;

  addButton?.addEventListener("click", () => {
    overviewCount++;

    const div = document.createElement("div");
    div.className = "form-section";

    const label = document.createElement("label");
    label.textContent = `Over View ${overviewCount}:`;

    const input = document.createElement("input");
    input.type = "text";
    input.name = `overview_${overviewCount}`;
    input.placeholder = "Enter details for this Over View";

    const imageWrapper = document.createElement("div");
    imageWrapper.className = "image-entry";

    const file = document.createElement("input");
    file.type = "file";
    file.accept = "image/*";
    file.capture = "environment";

    const desc = document.createElement("input");
    desc.type = "text";
    desc.placeholder = "Enter image description";

    imageWrapper.appendChild(file);
    imageWrapper.appendChild(desc);

    div.appendChild(label);
    div.appendChild(input);
    div.appendChild(imageWrapper);
    container.appendChild(div);
  });
}