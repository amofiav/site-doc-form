console.log("🚀 Script started...");

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, GetCommand } from "@aws-sdk/lib-dynamodb";
import assert from 'node:assert';

console.log("📦 Imported AWS SDK and assert!");

const client = new DynamoDBClient({ region: "us-east-2" });
const ddbDocClient = DynamoDBDocumentClient.from(client);

console.log("🔧 DynamoDB Client created!");

const TABLE_NAME = "SiteSubmissions";
const testSubmission = {
  submissionId: "test123",
  site: "Test Hospital",
  unit: "Test Unit",
  notes: "Testing notes",
};

console.log("📝 Test data prepared!");

async function testDynamoDBSave() {
  console.log("💥 Inside async function testDynamoDBSave()...");

  await ddbDocClient.send(new PutCommand({
    TableName: TABLE_NAME,
    Item: testSubmission,
  }));

  console.log("✅ Item written. Now verifying...");

  const result = await ddbDocClient.send(new GetCommand({
    TableName: TABLE_NAME,
    Key: { submissionId: "test123" },
  }));

  console.log("📦 Fetched item:", result.Item);

  assert.strictEqual(result.Item?.site, "Test Hospital");
  assert.strictEqual(result.Item?.unit, "Test Unit");

  console.log("✅ DynamoDB test passed!");
}

testDynamoDBSave().catch((err) => {
  console.error("❌ DynamoDB test failed:", err);
  process.exit(1);
});
