import fetch from 'node-fetch';
import assert from 'assert';

async function testSubmitForm() {
  console.log("🚀 Starting form submit test...");

  const payload = {
    site: "Test Site",
    unit: "Test Unit",
    notes: "This is a test submission",
    siteData: {},      // <- even if empty
    unitData: {},      // <- even if empty
    unitImages: []     // <- even if empty
  };

  const response = await fetch('https://oqvwp8amk6.execute-api.us-east-2.amazonaws.com/v1/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload) // 🛠️ THIS IS WHAT YOU WERE MISSING
  });

  const data = await response.json();

  console.log("🌐 HTTP status code:", response.status);
  console.log("📦 Response data:", data);

  assert(data.message === 'Submission stored successfully', "Expected success message inside response");

  console.log("✅ Form submit test passed.");
}

testSubmitForm().catch(console.error);
